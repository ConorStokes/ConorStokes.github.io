#ifndef BOONDOGGLE_VISUALIZER_H__
#define BOONDOGGLE_VISUALIZER_H__

#include <stdint.h>

#pragma once

void DisplayOculusVR( const wchar_t* packagePath );

void DisplayWindowed( const wchar_t* packagePath, uint32_t width, uint32_t height, float fovInDegrees );

#endif // -- BOONDOGGLE_VISUALIZER_H__