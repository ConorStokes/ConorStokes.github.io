#include <windows.h>
#include "visualizer.h"

int wmain( int argc, const wchar_t** argv )
{
    if ( argc < 2 )
    {
        DisplayOculusVR(L"example.bdg");
    }
    else
    {
        DisplayOculusVR( argv[ 1 ] );
    }
    //   DisplayWindowed( argv[ 1 ], 1440, 900, 70.0f );

    return 0;
}